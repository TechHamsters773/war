import Link from "next/link";

export default function Navbar() {
  return (
    <nav className="bg-gray-900 text-white p-4 flex gap-6 shadow-md">
      <Link href="/" className="hover:text-blue-400">Home</Link>
      <Link href="/donate" className="hover:text-blue-400">Donate</Link>
      <Link href="/dashboard" className="hover:text-blue-400">Dashboard</Link>
    </nav>
  );
}