import { useState } from "react";

export default function Home() {
  const [text, setText] = useState("");
  const [result, setResult] = useState(null);

  async function detectNews() {
    const res = await fetch("http://localhost:5000/detect-news", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text }),
    });
    const data = await res.json();
    setResult(data);
  }

  return (
    <div className="flex flex-col items-center justify-center">
      <div className="bg-white shadow-xl rounded-2xl p-6 max-w-2xl w-full">
        <h1 className="text-2xl font-bold text-center mb-4">📰 Fake News Detector</h1>
        <textarea
          className="border p-3 w-full rounded-md focus:ring-2 focus:ring-blue-500"
          rows={6}
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="Paste news text here..."
        />
        <button
          onClick={detectNews}
          className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 mt-4 rounded-lg w-full"
        >
          Detect News
        </button>

        {result && (
          <div className="mt-6 bg-gray-50 border rounded-lg p-4">
            <h2 className="font-semibold mb-2">Result:</h2>
            <pre className="whitespace-pre-wrap text-sm text-gray-800">
              {JSON.stringify(result, null, 2)}
            </pre>
          </div>
        )}
      </div>
    </div>
  );
}