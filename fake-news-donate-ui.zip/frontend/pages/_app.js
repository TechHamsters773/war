import '@/styles/globals.css'
import Navbar from '../components/Navbar'

export default function App({ Component, pageProps }) {
  return (
    <div className="bg-gray-100 min-h-screen">
      <Navbar />
      <main className="p-6">
        <Component {...pageProps} />
      </main>
    </div>
  )
}