import { useEffect, useState } from "react";
import { ethers } from "ethers";
import DonationTrackerABI from "../abi/DonationTracker.json";

const CONTRACT_ADDRESS = "YOUR_DEPLOYED_CONTRACT_ADDRESS";

export default function Dashboard() {
  const [donations, setDonations] = useState([]);

  async function loadDonations() {
    if (!window.ethereum) return alert("Please install MetaMask");

    const provider = new ethers.providers.Web3Provider(window.ethereum);
    await provider.send("eth_requestAccounts", []);

    const contract = new ethers.Contract(
      CONTRACT_ADDRESS,
      DonationTrackerABI,
      provider
    );

    const allDonations = await contract.getAllDonations();
    setDonations(allDonations);
  }

  useEffect(() => {
    loadDonations();
  }, []);

  return (
    <div className="flex flex-col items-center justify-center">
      <div className="bg-white shadow-xl rounded-2xl p-6 max-w-3xl w-full">
        <h1 className="text-2xl font-bold text-center mb-6">💰 Transparency Dashboard</h1>
        {donations.length === 0 ? (
          <p className="text-gray-600 text-center">No donations yet.</p>
        ) : (
          <table className="w-full border-collapse border border-gray-200">
            <thead>
              <tr className="bg-gray-100">
                <th className="p-2 border">Donor</th>
                <th className="p-2 border">Amount (ETH)</th>
                <th className="p-2 border">Tx Hash</th>
              </tr>
            </thead>
            <tbody>
              {donations.map((d, i) => (
                <tr key={i} className="hover:bg-gray-50">
                  <td className="p-2 border">{d.donor}</td>
                  <td className="p-2 border">{ethers.utils.formatEther(d.amount)}</td>
                  <td className="p-2 border text-xs">{d.txHash}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}