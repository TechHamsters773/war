import { useState } from "react";

export default function Donate() {
  const [amount, setAmount] = useState("");
  const [checkoutUrl, setCheckoutUrl] = useState(null);

  async function handleDonate() {
    const res = await fetch("http://localhost:5000/donate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ amount }),
    });
    const data = await res.json();
    setCheckoutUrl(data.url);
  }

  return (
    <div className="flex flex-col items-center justify-center">
      <div className="bg-white shadow-xl rounded-2xl p-6 max-w-md w-full">
        <h1 className="text-2xl font-bold text-center mb-4">💝 Donate</h1>
        <input
          type="number"
          className="border p-3 mt-2 w-full rounded-md"
          placeholder="Enter amount in USD"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
        />
        <button
          onClick={handleDonate}
          className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 mt-4 rounded-lg w-full"
        >
          Donate Now
        </button>

        {checkoutUrl && (
          <div className="mt-4 text-center">
            <a
              href={checkoutUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="text-blue-600 underline"
            >
              Complete Donation via Coinbase
            </a>
          </div>
        )}
      </div>
    </div>
  );
}