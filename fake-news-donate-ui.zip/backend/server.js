import express from "express";
import bodyParser from "body-parser";
import cors from "cors";
import { Client, resources } from "coinbase-commerce-node";
import fetch from "node-fetch";

const { Charge } = resources;
const app = express();
app.use(cors());
app.use(bodyParser.json());

// Coinbase setup
Client.init("YOUR_COINBASE_API_KEY");

// Route: Fake News Detection
app.post("/detect-news", async (req, res) => {
  const { text } = req.body;
  try {
    const response = await fetch("https://api-inference.huggingface.co/models/mrm8488/bert-tiny-finetuned-fake-news-detection", {
      method: "POST",
      headers: { 
        "Authorization": "Bearer YOUR_HUGGINGFACE_API_KEY",
        "Content-Type": "application/json" 
      },
      body: JSON.stringify({ inputs: text })
    });

    const data = await response.json();
    res.json(data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Route: Coinbase Donation
app.post("/donate", async (req, res) => {
  const { amount } = req.body;
  const chargeData = {
    name: "News Donation",
    description: "Support transparency project",
    local_price: { amount, currency: "USD" },
    pricing_type: "fixed_price",
  };

  try {
    const charge = await Charge.create(chargeData);
    res.json({ url: charge.hosted_url });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.listen(5000, () => console.log("Backend running on http://localhost:5000"));