async function main() {
  const DonationTracker = await ethers.getContractFactory("DonationTracker");
  const tracker = await DonationTracker.deploy();
  await tracker.deployed();
  console.log("DonationTracker deployed to:", tracker.address);
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});