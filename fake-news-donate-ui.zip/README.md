# Fake News Detection + Donation Transparency (Web3)

This project combines:
- Fake News Detection (HuggingFace AI)
- Donation Transparency (Coinbase + Blockchain)

## Setup

### 1. Smart Contract
```bash
npm install
npx hardhat compile
npx hardhat run scripts/deploy.js --network sepolia
```

### 2. Backend
```bash
cd backend
npm install express cors body-parser coinbase-commerce-node node-fetch
node server.js
```

### 3. Frontend
```bash
cd frontend
npx create-next-app .
npm install tailwindcss ethers
npm run dev
```

Visit:
- http://localhost:3000 -> Fake News Detector
- http://localhost:3000/donate -> Donate
- http://localhost:3000/dashboard -> Transparency Dashboard
